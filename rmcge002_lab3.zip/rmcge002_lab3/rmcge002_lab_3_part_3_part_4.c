/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 3 Exercise # 3 and 4
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


 //unsigned char myarray[4] ;
 //myarray 
#include <avr/io.h>

enum states {Start,Init,Control,Hash_Button,Hash_Release, 
Open_Door_Lock, Set_Door_Lock } state;

void tick(){
	switch(state){ //Transitions
	case Start:
		state = Init;
		break;
	case Init:
		 state = Control;
		 break;
	case Control:
		if (PINA == 0x04){
		state = Hash_Button;
		}
		else if (PINA == 0x80){
		state = Set_Door_Lock;
		}
		else{
		state = Control;
		}
		break;
	case Set_Door_Lock:
		state = Control;
		break;
	case Hash_Button:
		if (PINA == 0x04){
		state = Hash_Button;
		}			
		else if (PINA == 0x00){
		state = Hash_Release;
		}
		else if (PINA == 0x80){
		state = Set_Door_Lock;
		}
		else {
		state = Control;
		}
		break;
	case Hash_Release:
		if (PINA == 0x00){
		state = Hash_Release;
		}
		else if (PINA == 0x80){
		state = Set_Door_Lock;
		}
		else if (PINA == 0x02){
		state = Open_Door_Lock;
		}
		else {
		state = Control;
		}
		break;
	case Open_Door_Lock:
		state = Control;
		break;
	default:
		state = Init;
		break;
	}
	switch(state){//outputs
	case Start:
		PORTC = 0x00;
		break;
	case Init:
		PORTC = 0x01;
		PORTB = 0x00;
		break;
	case Control:
		PORTC = 0x02;
		break;
	case Set_Door_Lock:
		PORTC = 0x06;
		PORTB = 0x00;
		break;
	case Hash_Button:
		PORTC = 0x03;
		break;
	case Hash_Release:
		PORTC = 0x04;
		break;
	case Open_Door_Lock:
		PORTC = 0x05;
		if (PORTB == 0x01){
		PORTB = 0x00;
		}
		else{
		PORTB = 0x01;
		}
	
	}

}


int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs,
	
	DDRC = 0xFF; PORTC = 0x00; // Configure port B's 8 pins as outputs,
	

	PORTB = 0x00;
	PORTC = 0x00;
	
	state = Start;
    /* Replace with your application code */
    while (1) 
    {
	tick();
	
    }
}

