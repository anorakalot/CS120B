/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 3 Exercise # 1
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>

//PB0 and PB1 each connect to an LED, and PB0's LED is initially on. 
//Pressing a button connected to PA0 turns off PB0's LED and turns on PB1's LED, staying that way after button release. 
//Pressing the button again turns off PB1's LED and turns on PB0's LED.

enum states {Start, Off_Release , On_Button, On_Release, Off_Button} state;

void tick(){
	switch (state){//transitions;
	case Start:
		state = Off_Release;
		break;
	case Off_Release:
		//if A0 is 1 go to On_button
		if ((PINA &0x01) == 0x01){
			state = On_Button;
		}
		//if A0 is 0 stay in Off_release
		else{
			state = Off_Release;
		}
		break;
	case On_Button:
		//if A0 is 1 stay in On_button
		if ((PINA & 0x01) == 0x01){
			state =  On_Button;
		}
		//if A0 is off go to On_release
		else{
			state = On_Release;
		}
		break;
		
	case On_Release:

		if ((PINA & 0x01) == 0x01){
			state = Off_Button;
		}
		else{
			state = On_Release;
		}
		break;

	case Off_Button:
		if ((PINA & 0x01) == 0x01){
			state = Off_Button;
		}
		else{
			state = Off_Release;
		}
		break;

	default:
		state = Start;
		break;
	}

	switch (state){//actions

		case Start:
			break;

		case Off_Release:
			PORTB = 0x01;
			break;
		case On_Button:
			PORTB = 0x02;
			break;
		case On_Release:
			PORTB = 0x02;			
			break;
		case Off_Button:
			PORTB = 0x01;
			break;
		default:
			break;	
		
	}
}

int main(void)
{

	
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs,


	PORTB = 0x00;
	state = Start;

    /* Replace with your application code */
    while (1) 
    {

	tick();
	

    }
}

