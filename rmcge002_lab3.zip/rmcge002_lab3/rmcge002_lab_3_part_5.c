/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 3 Exercise # 5
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
 #include <avr/io.h>

enum states {Start,Init,Control,Button,Release,
Open_Door_Lock, Set_Door_Lock } state;

unsigned char password [] = {0x04,0x01,0x02,0x01};
 


unsigned char tmpD = 0x00;

void tick(){
	switch(state){ //Transitions
		case Start:
			state = Init;
			break;
		case Init:
			state = Control;
			break;
		case Control:
			if (PINA == password[tmpD]){
				state = Button;
			}

			else if (PINA == 0x80){
				state = Set_Door_Lock;
			}
			else if (PINA == 0x00){
				state = Control;
			}
			else{
				state = Control;
				tmpD = 0x00;
			}
			break;

		case Set_Door_Lock:
			state = Control;
			break;
		case Button:
			if (PINA == password[tmpD]){
				state = Button;
			}
			else if (PINA == 0x00){
				state = Release;
			}
			else if (PINA == 0x80){
				state = Set_Door_Lock;
			}
			else {
				state = Control;
				tmpD = 0;
			}
			break;
		case Release:

			if (tmpD==3){
				state = Open_Door_Lock;
			}
			else{
				state = Control;
				tmpD++;
			}


			break;
		case Open_Door_Lock:
			state = Control;
			break;
		default:
			state = Init;
		break;
	}
	switch(state){//outputs
		case Start:
			PORTC = 0x00;
			break;
		case Init:
			PORTC = 0x01;
			PORTB = 0x00;
			tmpD = 0x00;
			PORTD = tmpD;
			break;
		case Control:
			PORTC = 0x02;
			PORTD = tmpD;
			break;
		case Set_Door_Lock:
			PORTC = 0x06;
			PORTB = 0x00;
			PORTD = tmpD;
			break;
		case Button:
			PORTC = 0x03;
			PORTD = tmpD;
			break;
		case Release:
			PORTC = 0x04;
			PORTD = tmpD;
			break;
		case Open_Door_Lock:
			PORTC = 0x05;
			PORTD = tmpD;
			if (PORTB == 0x01){
				PORTB = 0x00;
			}
			else{
				PORTB = 0x01;
			}
		
	}

}


int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs,
	
	DDRC = 0xFF; PORTC = 0x00; // Configure port B's 8 pins as outputs,
	
	DDRD = 0xFF; PORTD = 0x00; //D as output


	PORTB = 0x00;
	PORTC = 0x00;
	
	state = Start;
	/* Replace with your application code */
	while (1)
	{
		tick();
		
	}
}


