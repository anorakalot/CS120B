/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 4 Exercise # 1
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>



int main(void)
{

DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
DDRC = 0xFF; PORTC = 0x00; // Configure port B's 8 pins as outputs,
// initialize to 0s
unsigned char tmpC = 0x00; // intermediate variable used for port updates
unsigned char tmpA = 0x00;

/* Replace with your application code */
while (1)
{

	tmpA = ~PINA & 0x0F;
		if (tmpA == 0x00){
			tmpC = 0x00;
		}
		else if (tmpA < 0x03){
			tmpC = 0x20;
		}
		else if (tmpA < 0x05){
			tmpC = 0x30;
		}
		else if (tmpA < 0x07){
			tmpC = 0x38;
		}
		else if (tmpA < 0x0A){
			tmpC = 0x3C;
		}
		else if (tmpA < 0x0D){
			tmpC = 0x3E;
		}
		else {
			tmpC = 0x3F;
		}

		if (tmpA < 0x04){
		tmpC = (tmpC & 0x3F) | 0x40;
		}

	PORTC = tmpC;
}

}

/*
	DDRA = 0x00; PORTA = 0xFF; // Configure PORTA as input, initialize to 1s
	DDRB = 0xFF; PORTB = 0x00; // Configure PORTB as outputs, initialize to 0s
	unsigned char led = 0x00;
	unsigned char button = 0x00;
	while(1)
	{
		// if PA0 is 1, set PB1PB0=01, else =10
		// 1) Read inputs
		button = ~PINA & 0x01; // button is connected to A0
		// 2) Perform Computation
		if (button) { // True if button is pressed
			led = (led & 0xFC) | 0x01; // Sets B to bbbbbb01
			// (clear rightmost 2 bits, then set to 01)
		}
		else {
			led = (led & 0xFC) | 0x02; // Sets B to bbbbbb10
			// (clear rightmost 2 bits, then set to 10)
		}
		// 3) Write output
		PORTB = led;
	}
	*/
//int main(void)
//{
//	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs
//	while(1)
//	{
//		PORTB = 0x0F; // Writes port B's 8 pins with 00001111
//	}
//}


