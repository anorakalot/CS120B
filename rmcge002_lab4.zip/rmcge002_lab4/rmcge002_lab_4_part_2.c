/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 4 Exercise # 2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
 //Buttons are connected to PA0 and PA1. Output for PORTC is initially 7. 
 //Pressing PA0 increments PORTC once (stopping at 9). Pressing PA1 decrements PORTC once (stopping at 0).
 // If both buttons are depressed (even if not initially simultaneously), PORTC resets to 0.

#include <avr/io.h>


enum states {Start,Init, Control, PA1_Press , PA0_Press, Reset,Add,Subtract} state;
	//inputs
unsigned char PORT_A_0;
unsigned char PORT_A_1;


void tick (){

	PORT_A_0 = ~PINA & 0x01;
	PORT_A_1 = ~PINA & 0x02;


	switch(state){//transitions
		
		case Start:
			state = Init;
			break;

		case Init:
			state = Control;
			break;

		case Control:
			if (PORT_A_0 == 0x01 && PORT_A_1 != 0x02){
				state = Add;
				
			}
			else if (PORT_A_0 != 0x01 && PORT_A_1 == 0x02){
				state = Subtract;
			}
			else if (PORT_A_0 == 0x01 && PORT_A_1 == 0x02){
				state = Reset;
			}

			else {
				state = Control;
			}
			break;

		case PA0_Press:
		
			if ( PORT_A_1 == 0x02 ){
				state = Reset;
			}

			else if (PORT_A_0 != 0x01){
				state = Control;
			}
			else if (PORT_A_0 == 0x01){
				state = PA0_Press;
			}
			else{
				state = PA0_Press;
			}
		
			break;

		case PA1_Press:
			if (PORT_A_0 == 0x01 ){
				state = Reset;
			}

			else if (PORT_A_1 == 0x02 ){
				state = PA1_Press;
			}

			else if (PORT_A_1 != 0x02 ){
				state = Control;
			}
			else{
				state = PA1_Press;
			}
			break;

		case Reset:
			if (PORT_A_0 != 0x01 && PORT_A_1 != 0x02){
				state = Control;
			}
			else{
				state = Reset;
			}
			break;
		case Add:
			state = PA0_Press;
			break;
		case Subtract:
			state = PA1_Press;
			break;

		default:
			state = Start;
			break;
	}

	switch(state){//actions
		case Start:
			break;
		case Init:
			PORTC = 0x00;
			break;
		case Reset:
			PORTC = 0x00;
			break;
		case Control:
			break;
		case PA1_Press:
			break;
		case PA0_Press:
			break;
		case Add:
			if (PORTC <= 0x08){
				PORTC = PORTC +1;
			}
			break;
		case Subtract:
			if (PORTC >= 0x01){
				PORTC = PORTC -1;
			}
			break;
	}
	

}

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	
	DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs,
	
	state = Start;

	/* Replace with your application code */
	while (1)
	{
		tick();
	}
}
