/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 4 Exercise # 3
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>

enum states {Start, Init,Control,Button,Check_X }state;


unsigned char array_index_max = 8;
unsigned char x = 0x00;
unsigned char button;
unsigned char lights[9] = {0x01,0x02,0x04,0x08,0x10,0x08,0x04,0x02,0x01};

void tick(){

	button = ~PINA & 0x01;
	switch(state){//transitions
		case Start:
			state = Init;
			break;
		case Init:
			state = Control;
			break;
		case Control:
			if (button == 0x01){
				state = Button;
			}
			else {
				state = Control;
			}
			break;
		case Button:
			if (button == 0x01){
				state = Button;
			}
			else{
				state = Check_X;
			}
			break;
		case Check_X:
			state   =  Control;
			break;
		default:
			state = Start;
			break;
	}

	switch(state){//outputs
		case Start:
			break;
		case Init:
			x = 0;
			break;
		case Control:
			PORTC = lights[x];
			break;
		case Button:
			break;
		case Check_X:
			if(x+1 > array_index_max){
				x = 0;
			}
			else {
				x = x+1;
			}
			break;
	}

}

int main(void)
{

	DDRA = 0x00; PORTA = 0xFF; //input
	DDRC = 0xFF; PORTC = 0x00; //output

	state = Start;

    /* Replace with your application code */
    while (1) 
    {
		tick();
    }
}

